# Firebase Login & Registration App

Package name: `com.example.himanshusharma16794`
Language: Java · minSdk 24 · targetSdk 34

## Features
- Register with name, email, mobile number, password + confirm password
- Login with email & password
- Forgot password (sends reset link by email)
- Auto-login if already signed in
- Home screen showing user details from Firestore
- Logout

## Setup (5 minutes)

1. **Open the project** in Android Studio (File → Open → select the `FirebaseAuthApp` folder). Let Gradle sync.

2. **Create a Firebase project** at https://console.firebase.google.com
   → Add project → give it any name.

3. **Add an Android app** in Firebase:
   - Android package name: `com.example.himanshusharma16794` (must match exactly)
   - Download **google-services.json**
   - Put it inside the `app/` folder → `FirebaseAuthApp/app/google-services.json`

4. **Enable Email/Password sign-in:**
   Firebase Console → Build → Authentication → Get started → Sign-in method → Email/Password → Enable → Save.

5. **Create Firestore database:**
   Firebase Console → Build → Firestore Database → Create database → start in test mode (or use the rules below).

6. **Run** the app on an emulator or phone.

## Recommended Firestore rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

## Project structure
```
app/src/main/java/com/example/himanshusharma16794/
├── LoginActivity.java      (launcher screen, login + forgot password)
├── RegisterActivity.java   (signup + saves user to Firestore)
└── HomeActivity.java       (shows user info + logout)
app/src/main/res/layout/
├── activity_login.xml
├── activity_register.xml
└── activity_home.xml
```

## Common errors
- **"File google-services.json is missing"** → step 3 not done.
- **"CONFIGURATION_NOT_FOUND" / sign-in fails** → Email/Password not enabled (step 4).
- **Home screen shows no phone number** → Firestore not created or rules block access (step 5).
